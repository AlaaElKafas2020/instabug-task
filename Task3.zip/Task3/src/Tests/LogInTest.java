package Tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.TestBaseSetup;
import Pages.LoginPage;

public class LogInTest extends TestBaseSetup {
	private WebDriver driver;

	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
	
	@Test
	public void verifyHomePage() {
		System.out.println("Login page test...");
		//LoginPage logoutpage= new LoginPage(driver);
		//logoutpage.Logout();
		
	}
}


