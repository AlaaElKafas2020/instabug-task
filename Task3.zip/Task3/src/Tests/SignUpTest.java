package Tests;

import org.testng.annotations.Test;

public class SignUpTest {
  @Test
  public void f() {
  }
}
