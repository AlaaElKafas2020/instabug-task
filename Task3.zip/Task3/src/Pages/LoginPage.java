package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	private WebDriver driver;
	//private By SignEmailIn = By.name("loginfmt");
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}
	public void SingleSignin(String SignEmail)
	{
		driver.manage().timeouts().pageLoadTimeout(15,TimeUnit.SECONDS);
		//WebElement Emailelement = driver.findElement(SignEmailIn);
		//Emailelement.sendKeys(SignEmail);
		//WebElement Nextelement = driver.findElement(NextButt);
		//Nextelement.click();
	}

}
