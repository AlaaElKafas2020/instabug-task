package ApiTests;

import static io.restassured.RestAssured.given;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class SimpleCreatenewCatogry {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "http://localhost:3030";
    }

    @Test
    public void createnewservice(){
      RestAssured.baseURI  = "http://localhost:3030/"; 
      Response res = given()
         .contentType("application/json")
         .body("{\"name\":\"Alaacat\"\n"+"\"id\":\"pcmcat12345\"\\n}")
         .when()
         .post("/categories");
      String body = res.getBody().asString();
      System.out.println(body);
      //Check the Result
      Assert.assertEquals(body.contains("Alaacat"),true);
    }
}

