package ApiTests;

import static io.restassured.RestAssured.given;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class SimpleCreatenewservices {

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = "http://localhost:3030";
    }

    @Test
    public void createnewservice(){
      RestAssured.baseURI  = "http://localhost:3030/"; 
      Response res = given()
         .contentType("application/json")
         .body("{\"name\":\"AlaaService\"}")
         .when()
         .post("services");
      String body = res.getBody().asString();
      System.out.println(body);
      //Check the Result
      Assert.assertEquals(body.contains("AlaaService"),true);
     // Assert.assertEquals("AlaaService", body.jsonPath().getStrig("name"));
    }
}

