package ApiTests;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class SimpleGetProduct {

	@Test
	public void GetProductHighPrice()
	{   
		 Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("http://localhost:3030/products?$sort[price]=-1")
	                .then()
	                .extract().response();
	        Assert.assertEquals(200, response.statusCode());
      
    
	}

}