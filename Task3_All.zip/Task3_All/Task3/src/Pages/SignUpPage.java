package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpPage {
	
	private WebDriver driver;
    private By CreateAccButt= By.xpath("//*[@id=\"login_link\"]/div[3]/a");
    private By firstname = By.name("firstname");
    private By lastname = By.name("lastname");
    private By reg_email = By.name("reg_email__");
    private By reg_emailConf = By.name("reg_email_confirmation__");
    private By reg_passwd = By.name("reg_passwd__");
    private By sex= By.xpath("//*[@id=\"u_0_4_Fl\"]");
    private By websubmit=By.name("websubmit");
    
	public SignUpPage(WebDriver driver) {
	this.driver=driver;
	}
	public void Signup(String first_name,String last_name, String reg_mail,String rpasswd)
	{	
		WebElement CreateAccButtelement = driver.findElement(CreateAccButt);
		CreateAccButtelement.click();
		WebElement firstname_ele = driver.findElement(firstname);
		firstname_ele.sendKeys(first_name);
		WebElement lastname_ele = driver.findElement(lastname);
		lastname_ele.sendKeys(last_name);
		WebElement reg_mail_ele = driver.findElement(reg_email);
		reg_mail_ele.sendKeys(reg_mail);
		WebElement reg_emailConf_ele = driver.findElement(reg_emailConf);
		reg_emailConf_ele.sendKeys(reg_mail);
		WebElement reg_passwd_ele = driver.findElement(reg_passwd);
		reg_passwd_ele.sendKeys(rpasswd);
		Select birthday_year_drp = new Select(driver.findElement(By.name("birthday_year")));
		birthday_year_drp.selectByVisibleText("1998");
		
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"u_0_w_QX\"]/span[1]"))).click().perform();

		//((JavascriptExecutor) driver).executeScript("arguments[0].click()", driver.findElement(By.xpath("//*[@id=\"u_0_6_Gj\"]")));
		
		WebElement websubmitelement = driver.findElement(websubmit);
		websubmitelement.click();
	}

}
