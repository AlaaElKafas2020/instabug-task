package Pages;


import java.sql.Timestamp;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import Base.Utilities;
import Base.ExcelUtil;
public class LoginPage {
	private WebDriver driver;
    private By SignEmailIn = By.name("email");
    private By SignPassword = By.name("pass");
    private By LogButton = By.name("login");
    
	public LoginPage(WebDriver driver) {
	this.driver=driver;
	}
	public void SingleSignin(String SignEmail,String SPassword)
	{	
		WebElement Emailelement = driver.findElement(SignEmailIn);
		Emailelement.sendKeys(SignEmail);
		WebElement Passelement = driver.findElement(SignPassword);
		Passelement.sendKeys(SPassword);
		WebElement LogButtonelement = driver.findElement(LogButton);
		LogButtonelement.click();
		 Date date = new Date();
		  Timestamp timestamp2 = new Timestamp(date.getTime());
		  
		  try {
		    Utilities u= new Utilities();
			u.takeScreenshot(driver,"Screenshot1");
		    ExcelUtil.WriteInExcel("Test User has been Logged in ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
