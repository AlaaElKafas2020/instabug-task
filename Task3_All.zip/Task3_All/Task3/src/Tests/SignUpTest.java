package Tests;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.ExcelUtil;
import Base.TestBaseSetup;
import Pages.SignUpPage;

public class SignUpTest  extends TestBaseSetup {
	private WebDriver driver;
	
	private String FName;
	private String LName;
	private String Email;
    private String pass;
	
	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
	
	@Test
	public void ValidSignUp() {
		System.out.println("Sign up page test...");
		SignUpPage signupObj= new SignUpPage(driver);
		try {
			FName=ExcelUtil.ReadFromExcel(3,0);
			LName= ExcelUtil.ReadFromExcel(3,1);
			Email= ExcelUtil.ReadFromExcel(3,2);
			pass= ExcelUtil.ReadFromExcel(3,3);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		signupObj.Signup(FName,LName, Email, pass);;
		
	}
  }

