package Tests;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Base.ExcelUtil;
import Base.TestBaseSetup;
import Pages.LoginPage;

public class LogInTest extends TestBaseSetup {
	private WebDriver driver;
	private String Email;
	private String Pass;
	
	@BeforeClass
	public void setUp() {
		driver=this.getDriver();
	}
	
	@Test
	public void ValidLogin() {
		System.out.println("Login page test...");
		LoginPage LogObj= new LoginPage(driver);
		try {
			 Email=ExcelUtil.ReadFromExcel(1,0);
			 Pass= ExcelUtil.ReadFromExcel(1,1);
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		LogObj.SingleSignin(Email, Pass);
		
	}
}


