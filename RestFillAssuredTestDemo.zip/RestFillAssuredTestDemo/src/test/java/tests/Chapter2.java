package tests;

import org.testng.annotations.Test;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


public class Chapter2 {
  @Test
  public void requestUsZipCode90210_checkStatusCode_expectHttp200() {

      given().when().get("http://zippopotam.us/us/90210").then().assertThat().statusCode(200);
      given().when().get("http://zippopotam.us/us/90210").then().assertThat().contentType(ContentType.JSON);
}
}
